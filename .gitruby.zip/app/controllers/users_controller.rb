class UsersController < ApplicationController
skip_before_action :authorized, only: [:create]

    def show
        current_user = find_user
        render json: current_user, status: :ok
    end
  

    def create 
        user = User.create!(user_params)
        session[:user_id] = user.id
        render json: user, status: :created
        
    end
end
